<script setup lang="ts">
// Drop a track at /public/music/track.mp3 to enable the player.
// If the file is missing, the button is gracefully disabled — no errors.
const MUSIC_SRC = '/music/track.mp3';

const audio = ref<HTMLAudioElement | null>(null);
const open = ref(false);
const playing = ref(false);
const available = ref(true); // flips to false if the file fails to load
const current = ref(0);
const duration = ref(0);

const fmt = (s: number) => {
  if (!Number.isFinite(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60).toString().padStart(2, '0');
  return `${m}:${sec}`;
};
const progress = computed(() =>
  duration.value ? (current.value / duration.value) * 100 : 0
);

const onError = () => { available.value = false; playing.value = false; open.value = false; };

const toggle = async () => {
  if (!audio.value || !available.value) return;
  if (playing.value) {
    audio.value.pause();
    playing.value = false;
  } else {
    try {
      await audio.value.play();
      playing.value = true;
    } catch { /* autoplay blocked or missing file — stay silent */ }
  }
};

const seek = (e: Event) => {
  if (!audio.value || !duration.value) return;
  const el = e.target as HTMLInputElement;
  audio.value.currentTime = (Number(el.value) / 100) * duration.value;
};

watch(open, (v) => { if (!v && playing.value) toggle(); });
</script>

<template>
  <div class="music">
    <audio
      v-if="available"
      ref="audio"
      :src="MUSIC_SRC"
      preload="none"
      @error="onError"
      @timeupdate="current = $event.target.currentTime"
      @loadedmetadata="duration = $event.target.duration"
      @ended="playing = false"
    />

    <button
      class="music-fab"
      :class="{ disabled: !available, active: open }"
      :aria-label="available ? 'Toggle music player' : 'Music unavailable (no track file)'"
      :aria-disabled="!available"
      @click="available && (open = !open)"
    >
      {{ playing ? '🔊' : '🎵' }}
    </button>

    <Transition name="pop">
      <div v-if="open && available" class="music-panel glass" role="dialog" aria-label="Music player">
        <div class="mp-head">
          <span class="mp-title">Now Playing ♪</span>
          <button class="mp-close" aria-label="Close music player" @click="open = false">✕</button>
        </div>
        <p class="mp-track">Archive Theme — Lius</p>
        <input
          class="mp-progress"
          type="range"
          min="0"
          max="100"
          step="0.1"
          :value="progress"
          aria-label="Seek"
          @input="seek"
        />
        <div class="mp-row">
          <button class="mp-play" :aria-label="playing ? 'Pause' : 'Play'" @click="toggle">
            {{ playing ? '⏸' : '▶' }}
          </button>
          <span class="mp-time">{{ fmt(current) }} / {{ fmt(duration) }}</span>
        </div>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
.music { position: fixed; bottom: 22px; right: 22px; z-index: 150; display: flex; flex-direction: column; align-items: flex-end; gap: 12px; }
.music-fab {
  width: 54px; height: 54px; border-radius: 50%; font-size: 1.4rem; cursor: pointer;
  background: var(--grad); border: none; color: #fff;
  box-shadow: 0 10px 26px rgba(255, 77, 141, 0.35);
  transition: transform 0.25s ease, opacity 0.25s ease;
}
.music-fab:hover { transform: scale(1.08); }
.music-fab.disabled { background: var(--surface-strong); border: 1px solid var(--border); opacity: 0.45; cursor: not-allowed; box-shadow: none; }
.music-panel { width: 250px; padding: 18px; }
.mp-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.mp-title { font-size: 0.74rem; letter-spacing: 0.18em; text-transform: uppercase; color: var(--accent-3); font-weight: 700; }
.mp-close { background: none; border: none; color: var(--muted); cursor: pointer; font-size: 0.9rem; padding: 4px; }
.mp-close:hover { color: var(--text); }
.mp-track { font-size: 0.88rem; font-weight: 600; margin-bottom: 12px; }
.mp-progress { width: 100%; accent-color: var(--accent); cursor: pointer; }
.mp-row { display: flex; align-items: center; gap: 12px; margin-top: 10px; }
.mp-play {
  width: 38px; height: 38px; border-radius: 50%; border: none; cursor: pointer;
  background: var(--grad); color: #fff; font-size: 0.95rem;
}
.mp-time { font-size: 0.76rem; color: var(--muted); font-variant-numeric: tabular-nums; }
.pop-enter-active, .pop-leave-active { transition: opacity 0.25s, transform 0.25s; }
.pop-enter-from, .pop-leave-to { opacity: 0; transform: translateY(10px) scale(0.96); }
</style>
