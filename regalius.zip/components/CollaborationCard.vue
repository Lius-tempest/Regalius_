<script setup lang="ts">
import type { CollaborationItem } from '~/data/collaborations';

const props = defineProps<{ collab: CollaborationItem }>();
const thumbFailed = ref(false);
const hasThumb = computed(() => !!props.collab.thumbnail && !thumbFailed.value);
</script>

<template>
  <article class="collab-card glass">
    <div class="thumb">
      <img
        v-if="hasThumb"
        :src="collab.thumbnail"
        :alt="`Thumbnail for ${collab.title}`"
        loading="lazy"
        @error="thumbFailed = true"
      />
      <div v-else class="ph thumb-ph" aria-hidden="true"><span>🤝</span></div>
      <span v-if="collab.placeholder" class="ph-tag">Sample</span>
      <span class="year-tag">{{ collab.year }}</span>
    </div>
    <div class="body">
      <h3>{{ collab.title }}</h3>
      <p class="people">
        <span v-for="(p, i) in collab.participants" :key="p">
          {{ p }}<span v-if="i < collab.participants.length - 1" class="sep">×</span>
        </span>
      </p>
      <p class="desc">{{ collab.description }}</p>
      <a
        v-if="collab.url"
        :href="collab.url"
        target="_blank"
        rel="noopener noreferrer"
        class="cl-link"
      >View project ↗</a>
      <span v-else class="cl-link muted">Link coming soon</span>
    </div>
  </article>
</template>

<style scoped>
.collab-card { overflow: hidden; transition: transform 0.3s ease, border-color 0.3s ease; }
.collab-card:hover { transform: translateY(-6px); border-color: rgba(255, 77, 141, 0.4); }
.thumb { position: relative; aspect-ratio: 16 / 9; }
.thumb img { width: 100%; height: 100%; object-fit: cover; }
.thumb-ph { width: 100%; height: 100%; font-size: 3rem; }
.year-tag {
  position: absolute; right: 12px; bottom: 12px;
  padding: 5px 14px; border-radius: 999px; font-size: 0.74rem; font-weight: 800;
  letter-spacing: 0.12em;
  background: rgba(11, 14, 26, 0.75); border: 1px solid var(--border); backdrop-filter: blur(6px);
}
.ph-tag {
  position: absolute; top: 12px; left: 12px;
  padding: 4px 12px; border-radius: 999px; font-size: 0.68rem; font-weight: 700;
  letter-spacing: 0.1em; text-transform: uppercase;
  background: rgba(255, 77, 141, 0.18); border: 1px solid rgba(255, 77, 141, 0.45); color: var(--accent);
}
.body { padding: 20px 22px 24px; }
.body h3 { font-size: 1.08rem; margin-bottom: 8px; }
.people { font-size: 0.8rem; color: var(--accent-3); font-weight: 600; margin-bottom: 10px; }
.people .sep { margin: 0 6px; color: var(--muted); }
.desc { color: var(--muted); font-size: 0.88rem; margin-bottom: 14px; }
.cl-link { font-size: 0.86rem; font-weight: 600; text-decoration: none; }
.cl-link:hover { text-decoration: underline; }
.cl-link.muted { color: var(--muted); }
</style>
