<script setup lang="ts">
const percent = ref(0);
const done = ref(false);
const hidden = ref(false); // fully removed from DOM after fade-out

let pctTimer: ReturnType<typeof setInterval> | undefined;
let failSafe: ReturnType<typeof setTimeout> | undefined;

onMounted(() => {
  // Animate percentage over ~1.6s.
  pctTimer = setInterval(() => {
    percent.value = Math.min(100, percent.value + Math.ceil(Math.random() * 9) + 3);
    if (percent.value >= 100) {
      clearInterval(pctTimer);
      done.value = true;
      setTimeout(() => { hidden.value = true; }, 600);
    }
  }, 90);

  // Fail-safe: never let the loader block the site — force-remove after 5s.
  failSafe = setTimeout(() => {
    clearInterval(pctTimer);
    done.value = true;
    setTimeout(() => { hidden.value = true; }, 600);
  }, 5000);
});

onBeforeUnmount(() => {
  clearInterval(pctTimer);
  clearTimeout(failSafe);
});
</script>

<template>
  <div v-if="!hidden" class="loader" :class="{ done }" aria-hidden="true">
    <div class="loader-inner">
      <p class="loader-text">Welcome to <span class="grad-text">Lius's</span> archive...</p>
      <div class="loader-bar"><div class="loader-fill" :style="{ width: percent + '%' }" /></div>
      <p class="loader-pct">{{ percent }}%</p>
    </div>
  </div>
</template>

<style scoped>
.loader {
  position: fixed; inset: 0; z-index: 999;
  display: flex; align-items: center; justify-content: center;
  background: var(--bg);
  transition: opacity 0.55s ease, visibility 0.55s ease;
  /* CSS fail-safe: even without JS, the overlay disappears after 8s */
  animation: force-hide 0.1s 8s forwards;
}
.loader.done { opacity: 0; visibility: hidden; pointer-events: none; }
@keyframes force-hide { to { opacity: 0; visibility: hidden; pointer-events: none; } }
.loader-inner { text-align: center; width: min(320px, 80vw); }
.loader-text { font-size: 1.05rem; color: var(--muted); margin-bottom: 22px; }
.loader-bar {
  height: 4px; border-radius: 4px; background: var(--surface-strong); overflow: hidden;
}
.loader-fill { height: 100%; background: var(--grad); border-radius: 4px; transition: width 0.15s ease; }
.loader-pct { margin-top: 12px; font-size: 0.82rem; letter-spacing: 0.2em; color: var(--accent-3); font-variant-numeric: tabular-nums; }
</style>
