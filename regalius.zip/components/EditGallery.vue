<script setup lang="ts">
import { edits, editCategories } from '~/data/edits';

const active = ref<string>('All');
const filtered = computed(() =>
  active.value === 'All' ? edits : edits.filter((e) => e.category === active.value)
);
</script>

<template>
  <section id="edits">
    <div class="container">
      <div class="sec-head reveal">
        <span class="kicker">Archive</span>
        <h2>My Edits <span class="grad-text">🎬</span></h2>
        <p>A collection of edits from 2024 until now — anime edits, AMVs, experiments, and collabs.</p>
      </div>

      <div class="filters reveal" role="tablist" aria-label="Filter edits by category">
        <button
          v-for="c in editCategories"
          :key="c"
          class="chip"
          :class="{ active: active === c }"
          role="tab"
          :aria-selected="active === c"
          @click="active = c"
        >{{ c }}</button>
      </div>

      <TransitionGroup name="list" tag="div" class="edits-grid">
        <EditCard v-for="edit in filtered" :key="edit.title" :edit="edit" class="reveal in" />
      </TransitionGroup>
    </div>
  </section>
</template>

<style scoped>
.filters { display: flex; flex-wrap: wrap; gap: 10px; justify-content: center; margin-bottom: 44px; }
.chip {
  padding: 9px 20px; border-radius: 999px; font-size: 0.84rem; font-weight: 600;
  background: var(--surface); border: 1px solid var(--border); color: var(--muted);
  cursor: pointer; transition: all 0.25s;
}
.chip:hover { color: var(--text); border-color: var(--accent-2); }
.chip.active { background: var(--grad); color: #fff; border-color: transparent; box-shadow: 0 8px 20px rgba(255, 77, 141, 0.3); }

.edits-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(290px, 1fr)); gap: 26px; }

.list-enter-active, .list-leave-active { transition: opacity 0.3s, transform 0.3s; }
.list-enter-from, .list-leave-to { opacity: 0; transform: scale(0.96); }
.list-leave-active { position: absolute; }
</style>
