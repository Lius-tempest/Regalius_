<script setup lang="ts">
import { collaborations } from '~/data/collaborations';
</script>

<template>
  <section id="collabs">
    <div class="container">
      <div class="sec-head reveal">
        <span class="kicker">Together</span>
        <h2>Collaborations <span class="grad-text">🤝</span></h2>
        <p>Projects made together with other creators and communities.</p>
      </div>

      <div class="collab-grid">
        <CollaborationCard
          v-for="c in collaborations"
          :key="c.title"
          :collab="c"
          class="reveal"
        />
      </div>
    </div>
  </section>
</template>

<style scoped>
.collab-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 26px; }
</style>
