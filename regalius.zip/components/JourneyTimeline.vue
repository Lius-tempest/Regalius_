<script setup lang="ts">
import { journey } from '~/data/journey';
</script>

<template>
  <section id="journey">
    <div class="container">
      <div class="sec-head reveal">
        <span class="kicker">Timeline</span>
        <h2>The Journey <span class="grad-text">📖</span></h2>
        <p>Every creator has a starting point. This one started in 2024.</p>
      </div>

      <ol class="timeline">
        <li v-for="(entry, i) in journey" :key="entry.year" class="t-item reveal" :style="{ transitionDelay: `${i * 90}ms` }">
          <div class="t-dot" aria-hidden="true" />
          <div class="t-card glass">
            <span class="t-year">{{ entry.year }}</span>
            <h3>{{ entry.title }}</h3>
            <p>{{ entry.description }}</p>
          </div>
        </li>
      </ol>
    </div>
  </section>
</template>

<style scoped>
.timeline { list-style: none; position: relative; max-width: 760px; margin: 0 auto; padding-left: 36px; }
.timeline::before {
  content: ''; position: absolute; left: 9px; top: 6px; bottom: 6px; width: 2px;
  background: linear-gradient(var(--accent), var(--accent-2), var(--accent-3));
  border-radius: 2px; opacity: 0.7;
}
.t-item { position: relative; padding-bottom: 36px; }
.t-item:last-child { padding-bottom: 0; }
.t-dot {
  position: absolute; left: -36px; top: 8px; width: 20px; height: 20px; border-radius: 50%;
  background: var(--bg); border: 3px solid var(--accent);
  box-shadow: 0 0 14px rgba(255, 77, 141, 0.55);
}
.t-card { padding: 24px 28px; transition: transform 0.3s ease, border-color 0.3s ease; }
.t-card:hover { transform: translateX(6px); border-color: rgba(124, 92, 255, 0.45); }
.t-year {
  font-size: 0.78rem; font-weight: 800; letter-spacing: 0.22em; color: var(--accent-3);
}
.t-card h3 { margin: 6px 0 8px; font-size: 1.25rem; }
.t-card p { color: var(--muted); font-size: 0.94rem; }
</style>
