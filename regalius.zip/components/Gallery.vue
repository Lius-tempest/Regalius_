<script setup lang="ts">
import { galleryItems } from '~/data/gallery';

const active = ref<number | null>(null);
const failed = ref<Set<number>>(new Set());

const markFailed = (i: number) => { failed.value = new Set(failed.value).add(i); };
const hasImg = (i: number) => galleryItems[i].src && !failed.value.has(i);

const open = (i: number) => { active.value = i; };
const close = () => { active.value = null; };
const step = (dir: 1 | -1) => {
  if (active.value === null) return;
  active.value = (active.value + dir + galleryItems.length) % galleryItems.length;
};

const onKey = (e: KeyboardEvent) => {
  if (active.value === null) return;
  if (e.key === 'Escape') close();
  if (e.key === 'ArrowRight') step(1);
  if (e.key === 'ArrowLeft') step(-1);
};

onMounted(() => window.addEventListener('keydown', onKey));
onBeforeUnmount(() => window.removeEventListener('keydown', onKey));
</script>

<template>
  <section id="gallery">
    <div class="container">
      <div class="sec-head reveal">
        <span class="kicker">Scrapbook</span>
        <h2>Gallery <span class="grad-text">🖼️</span></h2>
        <p>Screenshots, memories, artwork, and fragments of the journey. Click to view.</p>
      </div>

      <div class="masonry">
        <button
          v-for="(item, i) in galleryItems"
          :key="item.title"
          class="tile glass"
          :aria-label="`Open ${item.title}`"
          @click="open(i)"
        >
          <img
            v-if="hasImg(i)"
            :src="item.src"
            :alt="item.title"
            loading="lazy"
            @error="markFailed(i)"
          />
          <div v-else class="ph tile-ph" aria-hidden="true"><span>📷</span></div>
          <span class="tile-tag">{{ item.tag }}</span>
          <span class="tile-title">{{ item.title }}<em v-if="item.year"> · {{ item.year }}</em></span>
        </button>
      </div>
    </div>

    <Teleport to="body">
      <div
        v-if="active !== null"
        class="lightbox"
        role="dialog"
        aria-modal="true"
        :aria-label="galleryItems[active].title"
        @click.self="close"
      >
        <button class="lb-btn nav prev" aria-label="Previous image" @click="step(-1)">‹</button>
        <figure>
          <img
            v-if="galleryItems[active].src && !failed.has(active)"
            :src="galleryItems[active].src"
            :alt="galleryItems[active].title"
            @error="markFailed(active)"
          />
          <div v-else class="ph lb-ph" aria-hidden="true"><span>📷</span></div>
          <figcaption>
            <strong>{{ galleryItems[active].title }}</strong>
            <span v-if="galleryItems[active].caption">{{ galleryItems[active].caption }}</span>
            <em>{{ galleryItems[active].tag }}<template v-if="galleryItems[active].year"> · {{ galleryItems[active].year }}</template></em>
          </figcaption>
        </figure>
        <button class="lb-btn nav next" aria-label="Next image" @click="step(1)">›</button>
        <button class="lb-btn close" aria-label="Close gallery" @click="close">✕</button>
      </div>
    </Teleport>
  </section>
</template>

<style scoped>
.masonry { columns: 3 260px; column-gap: 20px; }
.tile {
  position: relative; display: block; width: 100%; margin-bottom: 20px; padding: 0;
  overflow: hidden; cursor: pointer; border: 1px solid var(--border);
  break-inside: avoid; transition: transform 0.3s ease, border-color 0.3s ease;
  background: var(--surface);
}
.tile:hover { transform: translateY(-5px); border-color: rgba(77, 215, 255, 0.45); }
.tile img { width: 100%; }
.tile-ph { aspect-ratio: 4 / 3; font-size: 2.4rem; }
.tile:nth-child(3n + 2) .tile-ph { aspect-ratio: 1; }
.tile:nth-child(3n) .tile-ph { aspect-ratio: 3 / 4; }
.tile-tag {
  position: absolute; top: 10px; left: 10px; padding: 4px 12px; border-radius: 999px;
  font-size: 0.66rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase;
  background: rgba(11, 14, 26, 0.75); border: 1px solid var(--border); backdrop-filter: blur(6px);
}
.tile-title {
  display: block; padding: 12px 14px; font-size: 0.82rem; color: var(--muted); text-align: left;
}
.tile-title em { font-style: normal; opacity: 0.7; }

.lightbox {
  position: fixed; inset: 0; z-index: 300; background: rgba(5, 6, 14, 0.9);
  display: flex; align-items: center; justify-content: center; padding: 24px;
  backdrop-filter: blur(8px);
}
.lightbox figure { max-width: min(860px, 92vw); text-align: center; }
.lightbox img { max-height: 72vh; width: auto; max-width: 100%; margin: 0 auto; border-radius: var(--radius-sm); }
.lb-ph { height: 50vh; border-radius: var(--radius-sm); font-size: 4rem; }
.lightbox figcaption { margin-top: 16px; display: flex; flex-direction: column; gap: 4px; }
.lightbox figcaption span { color: var(--muted); font-size: 0.9rem; }
.lightbox figcaption em { font-style: normal; font-size: 0.76rem; color: var(--accent-3); letter-spacing: 0.12em; text-transform: uppercase; }
.lb-btn {
  position: absolute; background: var(--surface-strong); border: 1px solid var(--border);
  color: var(--text); width: 46px; height: 46px; border-radius: 50%; cursor: pointer; font-size: 1.2rem;
  transition: background 0.25s;
}
.lb-btn:hover { background: rgba(255, 255, 255, 0.16); }
.lb-btn.close { top: 20px; right: 24px; }
.lb-btn.nav { top: 50%; transform: translateY(-50%); }
.lb-btn.prev { left: 18px; }
.lb-btn.next { right: 18px; }
</style>
