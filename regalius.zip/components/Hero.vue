<script setup lang="ts">
import { profile } from '~/data/profile';
</script>

<template>
  <section id="home" class="hero">
    <div class="container hero-inner">
      <div class="hero-text reveal">
        <span class="hero-kicker">📼 Personal digital archive — {{ profile.domain }}</span>
        <h1 class="grad-text">{{ profile.name.toUpperCase() }}</h1>
        <p class="hero-role">{{ profile.displayTitle }}</p>
        <p class="hero-desc">{{ profile.tagline }}</p>
        <div class="hero-cta">
          <a href="#edits" class="btn btn-primary">🎬 Explore My Edits</a>
          <a href="#journey" class="btn btn-ghost">📖 My Journey</a>
        </div>
      </div>

      <div class="hero-visual reveal">
        <div class="avatar glass">
          <!-- Profile / logo image placeholder. Replace src with a real photo. -->
          <div class="avatar-img ph" aria-label="Profile picture placeholder" role="img">
            <span>🎬</span>
          </div>
          <div class="avatar-meta">
            <strong>{{ profile.name }}</strong>
            <span>{{ profile.role }}</span>
            <span class="since">Editing since {{ profile.startedEditing }}</span>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.hero { min-height: 100svh; display: flex; align-items: center; padding-top: var(--nav-h); }
.hero-inner {
  display: grid; grid-template-columns: 1.15fr 0.85fr; gap: 56px; align-items: center; width: 100%;
}
.hero-kicker {
  display: inline-block; padding: 8px 18px; border-radius: 999px;
  background: var(--surface); border: 1px solid var(--border);
  font-size: 0.8rem; color: var(--muted); margin-bottom: 26px;
  backdrop-filter: blur(8px);
}
.hero h1 { margin-bottom: 10px; }
.hero-role {
  font-size: clamp(1rem, 2.4vw, 1.3rem); font-weight: 600;
  letter-spacing: 0.12em; color: var(--text); margin-bottom: 16px;
}
.hero-desc { color: var(--muted); max-width: 460px; font-size: 1.05rem; margin-bottom: 34px; }
.hero-cta { display: flex; gap: 16px; flex-wrap: wrap; }

.hero-visual { display: flex; justify-content: center; }
.avatar {
  width: min(320px, 100%); padding: 22px; text-align: center;
  transition: transform 0.35s ease;
}
.avatar:hover { transform: translateY(-6px); }
.avatar-img {
  width: 100%; aspect-ratio: 1; border-radius: 50%; font-size: 4rem; margin-bottom: 18px;
  border: 1px solid var(--border);
}
.avatar-meta { display: flex; flex-direction: column; gap: 2px; }
.avatar-meta strong { font-size: 1.2rem; letter-spacing: 0.06em; }
.avatar-meta span { color: var(--muted); font-size: 0.85rem; }
.avatar-meta .since { color: var(--accent-3); font-size: 0.78rem; margin-top: 6px; }

@media (max-width: 880px) {
  .hero-inner { grid-template-columns: 1fr; gap: 44px; text-align: center; }
  .hero-desc { margin-inline: auto; }
  .hero-cta { justify-content: center; }
  .hero { min-height: auto; padding: calc(var(--nav-h) + 60px) 0 70px; }
}
</style>
