<script setup lang="ts">
import { profile } from '~/data/profile';
</script>

<template>
  <footer class="footer">
    <div class="container footer-inner">
      <p>© 2026 {{ profile.name }}. All rights reserved.</p>
      <a href="#home" class="domain">{{ profile.domain }}</a>
      <p class="made">Preserved with ❤ — edits, collabs & memories since {{ profile.startedEditing }}.</p>
    </div>
  </footer>
</template>

<style scoped>
.footer { border-top: 1px solid var(--border); padding: 44px 0; text-align: center; }
.footer-inner { display: flex; flex-direction: column; gap: 8px; }
.footer p { color: var(--muted); font-size: 0.86rem; }
.domain {
  font-weight: 700; letter-spacing: 0.1em; text-decoration: none;
  background: var(--grad); -webkit-background-clip: text; background-clip: text; color: transparent;
}
.domain:hover { text-decoration: underline; }
.made { font-size: 0.76rem; opacity: 0.7; }
</style>
