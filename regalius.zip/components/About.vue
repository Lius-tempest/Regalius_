<script setup lang="ts">
import { profile } from '~/data/profile';
</script>

<template>
  <section id="about">
    <div class="container about-grid">
      <div class="about-card glass reveal">
        <span class="kicker">About</span>
        <h2>About <span class="grad-text">{{ profile.name }}</span> ✦</h2>
        <p>{{ profile.about.intro }}</p>
        <p class="personal">{{ profile.about.personal }}</p>
      </div>
      <dl class="facts reveal">
        <div class="fact glass"><dt>Name</dt><dd>{{ profile.name }}</dd></div>
        <div class="fact glass"><dt>Role</dt><dd>{{ profile.role }}</dd></div>
        <div class="fact glass"><dt>Started Editing</dt><dd>{{ profile.startedEditing }}</dd></div>
        <div class="fact glass"><dt>Archive</dt><dd>{{ profile.domain }}</dd></div>
      </dl>
    </div>
  </section>
</template>

<style scoped>
.about-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 28px; align-items: stretch; }
.about-card { padding: 40px; }
.kicker {
  display: inline-block; font-size: 0.78rem; font-weight: 700;
  letter-spacing: 0.28em; text-transform: uppercase; color: var(--accent); margin-bottom: 12px;
}
.about-card h2 { margin-bottom: 18px; }
.about-card p { color: var(--muted); margin-bottom: 14px; }
.about-card .personal { color: var(--text); opacity: 0.92; }
.facts { display: grid; gap: 16px; }
.fact { padding: 18px 24px; display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
.fact dt { color: var(--muted); font-size: 0.78rem; letter-spacing: 0.14em; text-transform: uppercase; }
.fact dd { font-weight: 700; font-size: 1.02rem; }
@media (max-width: 820px) {
  .about-grid { grid-template-columns: 1fr; }
  .about-card { padding: 30px 26px; }
}
</style>
