<script setup lang="ts">
import type { EditItem } from '~/data/edits';

const props = defineProps<{ edit: EditItem }>();

const thumbFailed = ref(false);
const showVideo = ref(false);
const hasThumb = computed(() => !!props.edit.thumbnail && !thumbFailed.value);
</script>

<template>
  <article class="edit-card glass">
    <div class="thumb">
      <img
        v-if="hasThumb"
        :src="edit.thumbnail"
        :alt="`Thumbnail for ${edit.title}`"
        loading="lazy"
        @error="thumbFailed = true"
      />
      <div v-else class="ph thumb-ph" aria-hidden="true"><span>🎞️</span></div>
      <span v-if="edit.placeholder" class="ph-tag">Sample</span>
      <span class="cat-tag">{{ edit.category }}</span>
      <button
        v-if="edit.videoUrl"
        class="play-overlay"
        :aria-label="`Play video: ${edit.title}`"
        @click="showVideo = true"
      >
        ▶
      </button>
    </div>

    <div class="body">
      <div class="meta">
        <span class="year">{{ edit.year }}</span>
        <span class="software">💻 {{ edit.software }}</span>
      </div>
      <h3>{{ edit.title }}</h3>
      <p>{{ edit.description }}</p>
      <a
        v-if="edit.tiktokUrl"
        :href="edit.tiktokUrl"
        target="_blank"
        rel="noopener noreferrer"
        class="tt-link"
      >Watch on TikTok ↗</a>
      <span v-else class="tt-link muted">TikTok link coming soon</span>
    </div>

    <Teleport to="body">
      <div v-if="showVideo" class="video-modal" role="dialog" aria-modal="true" @click.self="showVideo = false">
        <button class="close" aria-label="Close video" @click="showVideo = false">✕</button>
        <video :src="edit.videoUrl" controls autoplay playsinline />
      </div>
    </Teleport>
  </article>
</template>

<style scoped>
.edit-card { overflow: hidden; transition: transform 0.3s ease, border-color 0.3s ease; }
.edit-card:hover { transform: translateY(-6px); border-color: rgba(124, 92, 255, 0.4); }
.thumb { position: relative; aspect-ratio: 16 / 9; overflow: hidden; }
.thumb img { width: 100%; height: 100%; object-fit: cover; }
.thumb-ph { width: 100%; height: 100%; font-size: 3rem; }
.cat-tag {
  position: absolute; left: 12px; bottom: 12px;
  padding: 5px 14px; border-radius: 999px; font-size: 0.72rem; font-weight: 700;
  background: rgba(11, 14, 26, 0.75); border: 1px solid var(--border);
  backdrop-filter: blur(6px);
}
.ph-tag {
  position: absolute; top: 12px; left: 12px;
  padding: 4px 12px; border-radius: 999px; font-size: 0.68rem; font-weight: 700;
  letter-spacing: 0.1em; text-transform: uppercase;
  background: rgba(255, 77, 141, 0.18); border: 1px solid rgba(255, 77, 141, 0.45); color: var(--accent);
}
.play-overlay {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem; color: #fff; background: rgba(11, 14, 26, 0.35);
  border: none; cursor: pointer; opacity: 0; transition: opacity 0.25s;
}
.thumb:hover .play-overlay, .play-overlay:focus-visible { opacity: 1; }
.body { padding: 20px 22px 24px; }
.meta { display: flex; justify-content: space-between; font-size: 0.76rem; color: var(--muted); margin-bottom: 8px; }
.meta .year { font-weight: 800; color: var(--accent-3); letter-spacing: 0.14em; }
.body h3 { font-size: 1.08rem; margin-bottom: 8px; }
.body p { color: var(--muted); font-size: 0.88rem; margin-bottom: 14px; }
.tt-link { font-size: 0.86rem; font-weight: 600; text-decoration: none; }
.tt-link:hover { text-decoration: underline; }
.tt-link.muted { color: var(--muted); }

.video-modal {
  position: fixed; inset: 0; z-index: 300; background: rgba(5, 6, 14, 0.88);
  display: flex; align-items: center; justify-content: center; padding: 24px;
  backdrop-filter: blur(6px);
}
.video-modal video { max-width: min(900px, 100%); max-height: 80vh; border-radius: var(--radius-sm); }
.video-modal .close {
  position: absolute; top: 20px; right: 24px; background: var(--surface-strong);
  border: 1px solid var(--border); color: var(--text); width: 44px; height: 44px;
  border-radius: 50%; cursor: pointer; font-size: 1rem;
}
</style>
