<script setup lang="ts">
const links = [
  { label: 'Home', href: '#home' },
  { label: 'Journey', href: '#journey' },
  { label: 'Edits', href: '#edits' },
  { label: 'Collabs', href: '#collabs' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'About', href: '#about' },
  { label: 'Socials', href: '#socials' },
];

const open = ref(false);
const scrolled = ref(false);

onMounted(() => {
  const onScroll = () => { scrolled.value = window.scrollY > 24; };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
});

const close = () => { open.value = false; };
</script>

<template>
  <header class="navbar" :class="{ scrolled, open }">
    <nav class="container nav-inner" aria-label="Main navigation">
      <a href="#home" class="brand" @click="close">
        <span class="brand-dot" aria-hidden="true"></span>
        LIUS<span class="brand-sub">.archive</span>
      </a>

      <ul class="nav-links" :class="{ open }">
        <li v-for="l in links" :key="l.href">
          <a :href="l.href" @click="close">{{ l.label }}</a>
        </li>
      </ul>

      <button
        class="hamburger"
        :aria-expanded="open"
        aria-label="Toggle menu"
        @click="open = !open"
      >
        <span /><span /><span />
      </button>
    </nav>
  </header>
</template>

<style scoped>
.navbar {
  position: fixed; inset: 0 0 auto 0; z-index: 100; height: var(--nav-h);
  transition: background 0.3s ease, border-color 0.3s ease;
  border-bottom: 1px solid transparent;
}
.navbar.scrolled {
  background: rgba(11, 14, 26, 0.78);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  border-bottom-color: var(--border);
}
.nav-inner { display: flex; align-items: center; justify-content: space-between; height: var(--nav-h); }
.brand {
  font-weight: 800; letter-spacing: 0.18em; text-decoration: none; color: var(--text);
  display: flex; align-items: center; gap: 10px; font-size: 1.05rem;
}
.brand-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--grad); box-shadow: 0 0 12px var(--accent); }
.brand-sub { color: var(--muted); font-weight: 500; letter-spacing: 0.06em; font-size: 0.85rem; }

.nav-links { display: flex; gap: 26px; list-style: none; }
.nav-links a {
  color: var(--muted); text-decoration: none; font-size: 0.9rem; font-weight: 500;
  transition: color 0.25s;
}
.nav-links a:hover { color: var(--text); }

.hamburger {
  display: none; flex-direction: column; gap: 5px;
  background: none; border: none; cursor: pointer; padding: 8px;
}
.hamburger span {
  width: 24px; height: 2px; background: var(--text); border-radius: 2px;
  transition: transform 0.3s, opacity 0.3s;
}
.navbar.open .hamburger span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
.navbar.open .hamburger span:nth-child(2) { opacity: 0; }
.navbar.open .hamburger span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

@media (max-width: 820px) {
  .hamburger { display: flex; }
  .nav-links {
    position: fixed; top: var(--nav-h); left: 0; right: 0;
    flex-direction: column; gap: 0; padding: 8px 24px 20px;
    background: rgba(11, 14, 26, 0.96);
    backdrop-filter: blur(16px);
    border-bottom: 1px solid var(--border);
    transform: translateY(-8px); opacity: 0; pointer-events: none;
    transition: opacity 0.25s, transform 0.25s;
  }
  .nav-links.open { transform: none; opacity: 1; pointer-events: auto; }
  .nav-links li { border-bottom: 1px solid rgba(255, 255, 255, 0.05); }
  .nav-links li:last-child { border-bottom: none; }
  .nav-links a { display: block; padding: 14px 4px; font-size: 1rem; }
}
</style>
