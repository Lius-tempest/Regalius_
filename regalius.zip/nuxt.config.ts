// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  css: ['~/assets/css/main.css'],
  app: {
    head: {
      htmlAttrs: { lang: 'en' },
      title: 'Lius — Creator, Editor & Visual Storyteller',
      meta: [
        { name: 'description', content: 'Personal archive of Lius — video edits, TikTok projects, collaborations, and creator journey.' },
        { name: 'theme-color', content: '#0b0e1a' },
        // Open Graph
        { property: 'og:title', content: 'Lius — Creator, Editor & Visual Storyteller' },
        { property: 'og:description', content: 'Personal archive of Lius — video edits, TikTok projects, collaborations, and creator journey.' },
        { property: 'og:type', content: 'website' },
        { property: 'og:url', content: 'https://regalius.my.id' },
        { property: 'og:site_name', content: "Lius's Archive" },
        { name: 'twitter:card', content: 'summary_large_image' },
        { name: 'twitter:title', content: 'Lius — Creator, Editor & Visual Storyteller' },
        { name: 'twitter:description', content: 'Personal archive of Lius — video edits, TikTok projects, collaborations, and creator journey.' },
      ],
      link: [
        { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
      ],
    },
  },
  routeRules: {
    // prerender index route by default
    '/': { prerender: true },
  },
});
