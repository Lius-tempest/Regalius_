Put your music file here as: track.mp3

The floating music player (components/MusicPlayer.vue) looks for /music/track.mp3.
- No autoplay — visitors choose to play.
- If the file is missing, the button is automatically disabled. No errors.
