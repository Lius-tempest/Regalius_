Put edit thumbnails here, e.g. /images/edits/my-edit.jpg
Then reference them in data/edits.ts -> thumbnail: '/images/edits/my-edit.jpg'
