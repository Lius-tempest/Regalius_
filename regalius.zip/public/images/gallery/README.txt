Put gallery images here and reference them in data/gallery.ts (src field)
