Put collaboration thumbnails here and reference them in data/collaborations.ts
