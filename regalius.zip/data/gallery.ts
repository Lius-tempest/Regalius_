export interface GalleryItem {
  title: string;
  caption?: string;
  src: string; // '' = styled placeholder tile
  tag: 'Screenshot' | 'TikTok' | 'Thumbnail' | 'Memory' | 'Artwork' | 'Old Project' | string;
  year?: number;
}

// PLACEHOLDER DATA — replace with real screenshots, artwork, and memories.
export const galleryItems: GalleryItem[] = [
  { title: 'First edit screenshot', src: '', tag: 'Screenshot', year: 2024 },
  { title: 'TikTok moment', src: '', tag: 'TikTok', year: 2025 },
  { title: 'Edit thumbnail', src: '', tag: 'Thumbnail', year: 2025 },
  { title: 'Community memory', src: '', tag: 'Memory', year: 2025 },
  { title: 'Old project file', src: '', tag: 'Old Project', year: 2024 },
  { title: 'Fan artwork', src: '', tag: 'Artwork', year: 2026 },
  { title: 'Behind the edit', src: '', tag: 'Screenshot', year: 2026 },
  { title: 'Milestone post', src: '', tag: 'TikTok', year: 2026 },
];
