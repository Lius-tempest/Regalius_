export interface JourneyEntry {
  year: number;
  title: string;
  description: string;
}

// Add new years at the bottom — the timeline renders automatically.
export const journey: JourneyEntry[] = [
  {
    year: 2024,
    title: 'The Beginning',
    description:
      'Started learning video editing and created the first edits. Everything began here — small experiments, lots of mistakes, and a lot of fun.',
  },
  {
    year: 2025,
    title: 'Growing',
    description:
      'Created more TikTok content, experimented with different editing styles, and participated in collaborations and communities.',
  },
  {
    year: 2026,
    title: 'Lius',
    description:
      'Started collecting old works, collaborations, projects, and memories into a personal digital archive — this website.',
  },
];
