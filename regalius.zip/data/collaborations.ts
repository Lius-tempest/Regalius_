export interface CollaborationItem {
  title: string;
  year: number;
  participants: string[];
  thumbnail: string; // '' = styled placeholder
  description: string;
  url: string; // TikTok / video link
  placeholder?: boolean;
}

// PLACEHOLDER DATA — replace with real collaborations.
export const collaborations: CollaborationItem[] = [
  {
    title: 'Example Collaboration',
    year: 2025,
    participants: ['Lius', 'Creator'],
    thumbnail: '',
    description: 'Placeholder: a collaboration project with fellow editors. Replace this with the real story behind it.',
    url: '',
    placeholder: true,
  },
  {
    title: 'Community Edit Battle',
    year: 2025,
    participants: ['Lius', 'Community'],
    thumbnail: '',
    description: 'Placeholder: joined a friendly edit battle hosted by an editing community.',
    url: '',
    placeholder: true,
  },
  {
    title: 'Duo Edit — Coming Soon',
    year: 2026,
    participants: ['Lius', 'TBA'],
    thumbnail: '',
    description: 'Placeholder: a future collaboration. This slot is waiting for its story.',
    url: '',
    placeholder: true,
  },
];
