export interface EditItem {
  title: string;
  year: number;
  category: 'Anime Edit' | 'AMV' | 'Character Edit' | 'Collaboration' | 'Experimental' | string;
  thumbnail: string; // e.g. '/images/edits/example.jpg' — leave '' for a styled placeholder
  description: string;
  software: string;
  tiktokUrl: string;
  videoUrl?: string;
  placeholder?: boolean; // true = sample data, replace with real work
}

// PLACEHOLDER DATA — replace with real edits.
export const edits: EditItem[] = [
  {
    title: 'First Cut — Learning the Basics',
    year: 2024,
    category: 'Anime Edit',
    thumbnail: '',
    description: 'Placeholder: my very first editing project, learning cuts, transitions, and timing.',
    software: 'Alight Motion',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
  {
    title: 'Rhythm Practice',
    year: 2024,
    category: 'AMV',
    thumbnail: '',
    description: 'Placeholder: an early AMV experiment focused on beat syncing.',
    software: 'CapCut',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
  {
    title: 'Character Study',
    year: 2025,
    category: 'Character Edit',
    thumbnail: '',
    description: 'Placeholder: a character-focused edit with color grading and shake effects.',
    software: 'Alight Motion',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
  {
    title: 'Style Experiment #1',
    year: 2025,
    category: 'Experimental',
    thumbnail: '',
    description: 'Placeholder: trying out glow, CC, and velocity effects.',
    software: 'After Effects',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
  {
    title: 'Community Project',
    year: 2025,
    category: 'Collaboration',
    thumbnail: '',
    description: 'Placeholder: a multi-editor collaboration hosted by the community.',
    software: 'Alight Motion',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
  {
    title: 'Archive Reel 2026',
    year: 2026,
    category: 'Anime Edit',
    thumbnail: '',
    description: 'Placeholder: a recap edit combining highlights from the journey so far.',
    software: 'Alight Motion',
    tiktokUrl: '',
    videoUrl: '',
    placeholder: true,
  },
];

export const editCategories = ['All', ...new Set(edits.map((e) => e.category))];
