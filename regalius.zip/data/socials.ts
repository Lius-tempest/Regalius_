export interface SocialItem {
  name: string;
  url: string; // placeholder — replace with the real profile URL
  icon: 'tiktok' | 'instagram' | 'youtube' | 'github';
  handle: string; // display text, e.g. '@yourname'
}

export const socials: SocialItem[] = [
  { name: 'TikTok', url: '#', icon: 'tiktok', handle: '@yourname' },
  { name: 'Instagram', url: '#', icon: 'instagram', handle: '@yourname' },
  { name: 'YouTube', url: '#', icon: 'youtube', handle: 'Lius' },
  { name: 'GitHub', url: '#', icon: 'github', handle: 'yourname' },
];
