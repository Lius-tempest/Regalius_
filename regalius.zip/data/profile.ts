// Central place for personal info — update here and it reflects across the site.
export const profile = {
  name: 'Lius',
  displayTitle: 'Creative • Editor • Visual Storyteller',
  tagline: 'An archive of my edits, collaborations, projects, and memories.',
  role: 'Creator / Video Editor',
  startedEditing: 2024,
  domain: 'regalius.my.id',
  about: {
    intro:
      "Lius is a creator and video editor who started his editing journey in 2024. This website is a personal archive for collecting his works, collaborations, projects, and memories throughout his journey as a creator.",
    personal:
      "Hey, I'm Lius. What started in 2024 as random edits on my phone slowly turned into something I genuinely love — cutting clips to music, experimenting with styles, and sharing them on TikTok. This site is my digital scrapbook: the edits, the collabs, the experiments, and the memories along the way. Nothing fancy — just my journey, preserved.",
  },
};
