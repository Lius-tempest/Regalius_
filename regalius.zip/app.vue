<script setup lang="ts">
useReveal();
useHead({
  titleTemplate: (t) => (t ? `${t}` : 'Lius — Creator, Editor & Visual Storyteller'),
});
</script>

<template>
  <div>
    <LoadingScreen />
    <Navbar />

    <main id="main">
      <Hero />

      <!-- Short introduction -->
      <section class="intro">
        <div class="container">
          <div class="intro-card glass reveal">
            <span class="kicker">Hello there 👋</span>
            <h2>About <span class="grad-text">Lius</span></h2>
            <p>
              Lius is a creator and video editor who started his editing journey in 2024.
              This website is a personal archive for collecting his works, collaborations,
              projects, and memories throughout his journey as a creator.
            </p>
          </div>
        </div>
      </section>

      <JourneyTimeline />
      <EditGallery />
      <CollaborationGallery />
      <Gallery />
      <About />
      <SocialLinks />
    </main>

    <Footer />
    <MusicPlayer />
  </div>
</template>

<style scoped>
.intro { padding: 0 0 40px; }
.intro-card {
  max-width: 780px; margin: 0 auto; padding: 44px 48px; text-align: center;
}
.kicker {
  display: inline-block; font-size: 0.78rem; font-weight: 700;
  letter-spacing: 0.28em; text-transform: uppercase; color: var(--accent); margin-bottom: 12px;
}
.intro-card h2 { margin-bottom: 16px; }
.intro-card p { color: var(--muted); font-size: 1.02rem; }
@media (max-width: 640px) {
  .intro-card { padding: 32px 24px; }
}
</style>
