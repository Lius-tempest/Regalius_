// Lightweight scroll-reveal without any dependency.
// Elements with the `.reveal` class get `.in` when they enter the viewport.
export function useReveal() {
  let observer: IntersectionObserver | null = null;

  onMounted(() => {
    const els = document.querySelectorAll('.reveal:not(.in)');
    if (!('IntersectionObserver' in window)) {
      els.forEach((el) => el.classList.add('in'));
      return;
    }
    observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            observer?.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );
    els.forEach((el) => observer!.observe(el));
  });

  onBeforeUnmount(() => observer?.disconnect());
}
