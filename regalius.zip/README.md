# regalius.my.id — Lius's Personal Digital Archive

A personal portfolio + digital archive for **Lius** — creator & video editor since 2024.
Built with Nuxt 3 + Vue 3 + TypeScript, dark glassmorphism aesthetic, no heavy dependencies.

## Setup

```bash
npm install
npm run dev      # http://localhost:3000
npm run build
npm run generate # static build (recommended for a single-page archive)
```

## Where to edit content (all data-driven)

| Content | File |
|---|---|
| Personal info, about text | `data/profile.ts` |
| Timeline (journey) | `data/journey.ts` |
| Video edits | `data/edits.ts` |
| Collaborations | `data/collaborations.ts` |
| Social links | `data/socials.ts` |
| Gallery images | `data/gallery.ts` + `public/images/gallery/` |
| Theme colors | `assets/css/main.css` → `:root` variables |

## Media

- Place images in `public/images/...` and set the path (e.g. `/images/edits/x.jpg`) in the data files.
- Missing images never break the page — styled placeholders are shown instead.
- Music: drop `track.mp3` into `public/music/`. No autoplay; the player disables itself if the file is missing.

## Components

`components/` — Navbar, Hero, JourneyTimeline, EditCard, EditGallery, CollaborationCard,
CollaborationGallery, Gallery (lightbox), About, SocialLinks, MusicPlayer, LoadingScreen, Footer.

## Deploy

Any static host works: `npm run generate` → deploy `.output/public` to Vercel / Netlify / Cloudflare Pages.

---
© 2026 Lius. All rights reserved. — regalius.my.id
